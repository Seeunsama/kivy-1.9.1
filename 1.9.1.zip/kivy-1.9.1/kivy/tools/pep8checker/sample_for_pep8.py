""" A docstring only file.  With double spaces.
"""
pass
""" Another comment. With single spaces. OK. """
pass
""" Another comment.  With double spaces.   And triple. """
pass
""" A mulitline one with initials C.C.M.
    And a double space in the middle.  Here.
    But not on the third. Line. """
pass
if True:
    " Single quotes.  Same issue.  With indent. "
    pass
else:
    """

    A multiline.



    On the third line.
         With odd indents.  Here.
    """

""" One with.  1 number doesn't count. lowercase doesn't.    Four doesn't.  """
pass
""" No we have commas,  with too many spaces.  a lower case sentence.
    then more:  issues,  and, then;  another issue """
pass
""" And then lots of blank lines. """






