.. _advancedgraphics:

Advanced Graphics
=================

Create your own Shader
----------------------

Rendering in a Framebuffer
--------------------------

Optimizations
-------------
